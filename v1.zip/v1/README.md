# Burgess Group Website

This website is created for [Dr. Kevin Burgess](https://www.chem.tamu.edu/faculty/kevin-burgess/) at Texas A&M University and maintained by [Rui-Liang Lyu](https://lyu18.github.io/).

The website is to be hosted at [https://www.chem.tamu.edu/rgroup/burgess/](https://www.chem.tamu.edu/rgroup/burgess/).
